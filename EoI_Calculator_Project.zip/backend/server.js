
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');

mongoose.connect('mongodb://localhost:27017/eoi', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.error(err));

const app = express();

app.use(cors());
app.use(bodyParser.json());

const localitySchema = new mongoose.Schema({
    name: String,
    transportation: Number,
    airQuality: Number,
    safety: Number,
    education: Number,
    healthcare: Number,
    housing: Number
});

const Locality = mongoose.model('Locality', localitySchema);

app.get('/localities', async (req, res) => {
    const localities = await Locality.find();
    res.json(localities);
});

app.post('/localities', async (req, res) => {
    const locality = new Locality(req.body);
    await locality.save();
    res.json(locality);
});

const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
